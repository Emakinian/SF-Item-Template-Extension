﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;

namespace $ModelNamespace$
{
	public class $fileinputname$Model
	{
	    $if$ ($ModelType0$ != null) public $ModelType0$ $ModelName0$ { get; set; }$endif$
        $if$ ($ModelType1$ != null) public $ModelType1$ $ModelName1$ { get; set; }$endif$
        $if$ ($ModelType2$ != null) public $ModelType2$ $ModelName2$ { get; set; }$endif$
        $if$ ($ModelType3$ != null) public $ModelType3$ $ModelName3$ { get; set; }$endif$
        $if$ ($ModelType4$ != null) public $ModelType4$ $ModelName4$ { get; set; }$endif$
        $if$ ($ModelType5$ != null) public $ModelType5$ $ModelName5$ { get; set; }$endif$
        $if$ ($ModelType6$ != null) public $ModelType6$ $ModelName6$ { get; set; }$endif$
        $if$ ($ModelType7$ != null) public $ModelType7$ $ModelName7$ { get; set; }$endif$
        $if$ ($ModelType8$ != null) public $ModelType8$ $ModelName8$ { get; set; }$endif$
        $if$ ($ModelType9$ != null) public $ModelType9$ $ModelName9$ { get; set; }$endif$
        $if$ ($ModelType10$ != null) public $ModelType10$ $ModelName10$ { get; set; }$endif$
        $if$ ($ModelType11$ != null) public $ModelType11$ $ModelName11$ { get; set; }$endif$
        $if$ ($ModelType12$ != null) public $ModelType12$ $ModelName12$ { get; set; }$endif$
        $if$ ($ModelType13$ != null) public $ModelType13$ $ModelName13$ { get; set; }$endif$
        $if$ ($ModelType14$ != null) public $ModelType14$ $ModelName14$ { get; set; }$endif$
        $if$ ($ModelType15$ != null) public $ModelType15$ $ModelName15$ { get; set; }$endif$
        $if$ ($ModelType16$ != null) public $ModelType16$ $ModelName16$ { get; set; }$endif$
        $if$ ($ModelType17$ != null) public $ModelType17$ $ModelName17$ { get; set; }$endif$
        $if$ ($ModelType18$ != null) public $ModelType18$ $ModelName18$ { get; set; }$endif$
        $if$ ($ModelType19$ != null) public $ModelType19$ $ModelName19$ { get; set; }$endif$
        $if$ ($ModelType20$ != null) public $ModelType20$ $ModelName20$ { get; set; }$endif$
    }
}
